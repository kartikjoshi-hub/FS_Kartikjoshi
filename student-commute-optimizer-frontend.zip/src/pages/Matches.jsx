import MatchCard from "../components/MatchCard";

export default function Matches() {
  const sampleMatches = [
    { id: 1, name: "Rahul", overlap: "70%", time: "8:15 AM" },
    { id: 2, name: "Aisha", overlap: "60%", time: "8:20 AM" },
  ];

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Suggested Matches</h2>
      <div className="grid gap-4">
        {sampleMatches.map(m => (
          <MatchCard key={m.id} match={m} />
        ))}
      </div>
    </div>
  );
}