import MapView from "../components/MapView";

export default function Home() {
  return (
    <div className="h-screen">
      <h2 className="text-xl font-bold p-4">Enter your route</h2>
      <MapView />
    </div>
  );
}