import ChatBox from "../components/ChatBox";

export default function Chat() {
  return (
    <div className="h-screen flex flex-col">
      <h2 className="text-xl font-bold p-4">Chat</h2>
      <ChatBox />
    </div>
  );
}