import { useState } from "react";

export default function ChatBox() {
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");

  const send = () => {
    if (!text.trim()) return;
    setMessages([...messages, { id: Date.now(), body: text }]);
    setText("");
  };

  return (
    <div className="flex-1 flex flex-col">
      <div className="flex-1 p-4 overflow-y-auto bg-gray-50">
        {messages.map(m => (
          <p key={m.id} className="mb-2 p-2 bg-white rounded shadow">
            {m.body}
          </p>
        ))}
      </div>
      <div className="flex p-2 bg-gray-200">
        <input
          value={text}
          onChange={e => setText(e.target.value)}
          className="flex-1 p-2 rounded-l border"
          placeholder="Type a message..."
        />
        <button
          onClick={send}
          className="px-4 bg-blue-500 text-white rounded-r"
        >
          Send
        </button>
      </div>
    </div>
  );
}