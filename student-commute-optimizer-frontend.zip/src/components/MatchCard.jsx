export default function MatchCard({ match }) {
  return (
    <div className="p-4 bg-white shadow rounded-xl flex justify-between items-center">
      <div>
        <p className="font-semibold">{match.name}</p>
        <p>Overlap: {match.overlap}</p>
        <p>Time: {match.time}</p>
      </div>
      <button className="px-3 py-1 bg-blue-500 text-white rounded-lg">
        Chat
      </button>
    </div>
  );
}