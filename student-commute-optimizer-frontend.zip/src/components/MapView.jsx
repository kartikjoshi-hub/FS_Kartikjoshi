import { useState } from "react";
import Map, { Marker } from "react-map-gl";

export default function MapView() {
  const [viewState, setViewState] = useState({
    longitude: 77.209,
    latitude: 28.6139,
    zoom: 10,
  });

  return (
    <div className="h-[80vh]">
      <Map
        {...viewState}
        onMove={evt => setViewState(evt.viewState)}
        mapboxAccessToken={import.meta.env.VITE_MAPBOX_TOKEN}
        mapStyle="mapbox://styles/mapbox/streets-v11"
      >
        <Marker longitude={77.209} latitude={28.6139} color="red" />
      </Map>
    </div>
  );
}