const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');
const path = require('path');

const DB_FILE = path.join(__dirname, 'db.json');

// Initialize simple JSON DB (low dependency approach but using plain file)
function loadDB() {
  if (!fs.existsSync(DB_FILE)) {
    const initial = { users: [], routes: [], carpools: [], messages: [] };
    fs.writeFileSync(DB_FILE, JSON.stringify(initial, null, 2));
  }
  return JSON.parse(fs.readFileSync(DB_FILE));
}

function saveDB(db) {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

// Simple haversine distance
function haversine(lat1, lon1, lat2, lon2) {
  function toRad(deg){ return deg * Math.PI / 180; }
  const R = 6371000; // meters
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a = Math.sin(dLat/2)*Math.sin(dLat/2) +
            Math.cos(toRad(lat1))*Math.cos(toRad(lat2)) *
            Math.sin(dLon/2)*Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

// Interpolate straight-line polyline (n points) between two coords
function straightPolyline(start, end, n=20) {
  const pts = [];
  for (let i=0;i<=n;i++){
    const t = i / n;
    const lat = start.lat + (end.lat - start.lat) * t;
    const lon = start.lon + (end.lon - start.lon) * t;
    pts.push({lat, lon});
  }
  return pts;
}

// Overlap heuristic: fraction of points from routeA that are within threshold m of any point on routeB
function overlapFraction(polyA, polyB, thresholdMeters=300) {
  let count = 0;
  for (const pa of polyA) {
    for (const pb of polyB) {
      if (haversine(pa.lat, pa.lon, pb.lat, pb.lon) <= thresholdMeters) {
        count++;
        break;
      }
    }
  }
  return count / polyA.length;
}

const app = express();
app.use(bodyParser.json());
app.use(cors());

// --- Endpoints ---

// Health
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: Date.now() });
});

// Signup (unique username enforced case-insensitive)
app.post('/api/auth/signup', (req, res) => {
  const { username, displayName, password } = req.body;
  if (!username || !password) return res.status(400).json({error: 'username and password required'});
  const db = loadDB();
  const norm = username.trim().toLowerCase();
  if (db.users.find(u => u.normUsername === norm)) {
    return res.status(409).json({ error: 'username already taken' });
  }
  const user = {
    id: uuidv4(),
    username,
    normUsername: norm,
    displayName: displayName || username,
    passwordHash: 'plain-' + password, // DEMO only; don't store plain passwords
    createdAt: new Date().toISOString()
  };
  db.users.push(user);
  saveDB(db);
  // Return a fake token for demo
  res.json({ userId: user.id, token: 'demo-token-' + user.id });
});

// Login (demo)
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  const db = loadDB();
  const norm = username.trim().toLowerCase();
  const user = db.users.find(u => u.normUsername === norm && u.passwordHash === 'plain-' + password);
  if (!user) return res.status(401).json({ error: 'invalid credentials' });
  res.json({ userId: user.id, token: 'demo-token-' + user.id });
});

// Save profile (home/destination)
app.post('/api/profile', (req, res) => {
  const { userId, home, destination, preferredDepartureTime, role, vehicleCapacity } = req.body;
  if (!userId || !home || !destination) return res.status(400).json({ error: 'userId, home and destination required' });
  const db = loadDB();
  const user = db.users.find(u => u.id === userId);
  if (!user) return res.status(404).json({ error: 'user not found' });
  user.profile = {
    home,
    destination,
    preferredDepartureTime: preferredDepartureTime || null,
    role: role || 'passenger',
    vehicleCapacity: vehicleCapacity || null
  };
  saveDB(db);
  res.json({ ok: true, profile: user.profile });
});

// Compute route (simple straight-line polyline) - returns polyline & distance/duration estimate
app.post('/api/route/compute', (req, res) => {
  const { origin, destination } = req.body;
  if (!origin || !destination) return res.status(400).json({ error: 'origin and destination required' });
  const poly = straightPolyline(origin, destination, 30);
  // naive distance estimate: sum haversine
  let dist = 0;
  for (let i=1;i<poly.length;i++){
    dist += haversine(poly[i-1].lat, poly[i-1].lon, poly[i].lat, poly[i].lon);
  }
  const durationSec = Math.round(dist / (40/3.6)); // assume avg 40 km/h -> m/s conversion
  res.json({ polyline: poly, distanceMeters: Math.round(dist), durationSeconds: durationSec });
});

// Save route
app.post('/api/route', (req, res) => {
  const { userId, polyline, distanceMeters, durationSeconds } = req.body;
  if (!userId || !polyline) return res.status(400).json({ error: 'userId and polyline required' });
  const db = loadDB();
  const user = db.users.find(u => u.id === userId);
  if (!user) return res.status(404).json({ error: 'user not found' });
  const route = {
    id: uuidv4(),
    userId,
    polyline,
    distanceMeters: distanceMeters || null,
    durationSeconds: durationSeconds || null,
    createdAt: new Date().toISOString()
  };
  db.routes.push(route);
  saveDB(db);
  res.json({ ok: true, route });
});

// Match suggestions - simple heuristic: compute overlap fraction with other routes; return top N
app.get('/api/match/suggestions', (req, res) => {
  const userId = req.query.userId;
  const radius = parseInt(req.query.radius || '300'); // meters threshold for overlap
  const limit = parseInt(req.query.limit || '10');
  if (!userId) return res.status(400).json({ error: 'userId required' });
  const db = loadDB();
  const myRoutes = db.routes.filter(r => r.userId === userId);
  if (myRoutes.length === 0) return res.json({ suggestions: [] });
  const myRoute = myRoutes[myRoutes.length -1]; // most recent
  const candidates = [];
  for (const r of db.routes) {
    if (r.userId === userId) continue;
    const frac = overlapFraction(myRoute.polyline, r.polyline, radius);
    if (frac > 0.05) {
      candidates.push({ routeId: r.id, userId: r.userId, overlapFraction: frac, distanceMeters: r.distanceMeters });
    }
  }
  candidates.sort((a,b) => b.overlapFraction - a.overlapFraction);
  res.json({ suggestions: candidates.slice(0, limit) });
});

// Create carpool proposal
app.post('/api/match/propose', (req, res) => {
  const { driverId, passengerId, routeId, startTime } = req.body;
  if (!driverId || !passengerId || !routeId) return res.status(400).json({ error: 'driverId, passengerId and routeId required' });
  const db = loadDB();
  const carpool = {
    id: uuidv4(),
    driverId,
    passengers: [{ userId: passengerId, status: 'proposed' }],
    routeId,
    startTime: startTime || null,
    createdAt: new Date().toISOString()
  };
  db.carpools.push(carpool);
  saveDB(db);
  res.json({ ok: true, carpool });
});

// Basic chat message save (no realtime)
app.post('/api/chat/message', (req, res) => {
  const { fromUser, toUser, body } = req.body;
  if (!fromUser || !body) return res.status(400).json({ error: 'fromUser and body required' });
  const db = loadDB();
  const msg = {
    id: uuidv4(),
    fromUser,
    toUser: toUser || null,
    body,
    createdAt: new Date().toISOString()
  };
  db.messages.push(msg);
  saveDB(db);
  res.json({ ok: true, message: msg });
});

// Get messages for a thread (simple filter)
app.get('/api/chat/messages', (req, res) => {
  const { userA, userB } = req.query;
  const db = loadDB();
  let msgs = db.messages;
  if (userA && userB) {
    msgs = msgs.filter(m => (m.fromUser === userA && m.toUser === userB) || (m.fromUser === userB && m.toUser === userA));
  } else if (userA) {
    msgs = msgs.filter(m => m.fromUser === userA || m.toUser === userA);
  }
  res.json({ messages: msgs });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log('Server listening on port', PORT);
});
