# Student Commute Optimizer - Backend (Demo)

Minimal Express backend for demo/prototyping. This implementation uses a plain JSON file (`db.json`) to persist data 
(not suitable for production). It provides endpoints for signup/login, saving profiles, computing & saving routes,
fetching simple match suggestions, proposing carpools, and basic chat message persistence.

## Run locally
```bash
cd student-commute-optimizer-backend
npm install
npm start
```

Server runs at `http://localhost:4000`.

## Endpoints (selection)
- `GET /api/health`
- `POST /api/auth/signup` { username, displayName, password }
- `POST /api/auth/login` { username, password }
- `POST /api/profile` { userId, home, destination, preferredDepartureTime, role, vehicleCapacity }
- `POST /api/route/compute` { origin: {lat, lon}, destination: {lat, lon} }
- `POST /api/route` { userId, polyline, distanceMeters, durationSeconds }
- `GET /api/match/suggestions?userId=...&radius=300&limit=10`
- `POST /api/match/propose` { driverId, passengerId, routeId }
- `POST /api/chat/message` { fromUser, toUser, body }
- `GET /api/chat/messages?userA=...&userB=...`

## Notes
- Passwords are stored as `plain-` for demo only. Replace with bcrypt and real DB for production.
- Route computation is a straight-line interpolated polyline (placeholder). Replace with OSRM/Mapbox for real routing.
- Matching is a simple overlap heuristic; replace with PostGIS + H3 logic for production.
- `db.json` is located at project root and will be created on first run.
